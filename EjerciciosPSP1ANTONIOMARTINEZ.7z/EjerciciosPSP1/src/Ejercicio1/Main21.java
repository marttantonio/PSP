package Ejercicio1;

import java.util.ArrayList;
import java.util.Scanner;

public class Main21 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		ArrayList<String> personas = new ArrayList<>();
		
		String p;
		for (int i = 0; i <5 ; i++) {
			System.out.println("Introduce la persona " + (i+1));
			p = teclado.next();
			personas.add(p);
		}
		
		for(String pe : personas) {
			System.out.println(pe);
		}

	}
}
