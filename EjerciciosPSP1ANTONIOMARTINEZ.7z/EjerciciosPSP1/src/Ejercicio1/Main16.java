package Ejercicio1;

import java.util.Scanner;

public class Main16 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		int dia;
		int mes;
		int anyo;

		System.out.println("Dime el dia que naciste");
		dia = teclado.nextInt();
		
		System.out.println("Dime el mes en el que naciste(numérico)");
		mes = teclado.nextInt();
		
		System.out.println("Dime el año en el que naciste");
		anyo = teclado.nextInt();
		
		int numsuerte = dia *2 / mes * 7 + anyo;
		
		System.out.println(numsuerte);
	}

}
