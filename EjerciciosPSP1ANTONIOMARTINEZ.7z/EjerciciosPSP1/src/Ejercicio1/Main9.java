package Ejercicio1;

import java.util.Scanner;

public class Main9 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introuce un número del 1 al 12 y te diré al mes del año al que corresponde");
		int nummes=teclado.nextInt();
		
		switch(nummes) {
		
		case 1:
			System.out.println("El numero corresponde a Enero");
			break;
		case 2:
			System.out.println("El numero corresponde a Febrero");
			break;
		case 3:
			System.out.println("El numero corresponde a Marzo");
			break;
		case 4:
			System.out.println("El numero corresponde a Abril");
			break;
		case 5:
			System.out.println("El numero corresponde a Mayo");
			break;
		case 6:
			System.out.println("El numero corresponde a Junio");
			break;
		case 7:
			System.out.println("El numero corresponde a Julio");
			break;
		case 8:
			System.out.println("El numero corresponde a Agosto");
			break;
		case 9:
			System.out.println("El numero corresponde a Septiembre");
			break;
		case 10:
			System.out.println("El numero corresponde a Octubre");
			break;
		case 11:
			System.out.println("El numero corresponde a Noviembre");
			break;
		case 12:
			System.out.println("El numero corresponde a Diciembre");
			break;
			default:
				System.out.println("Introduce un numero del 1 al 12");
		
		}
		
	}

}
