package Ejercicio1;

import java.util.ArrayList;
import java.util.Scanner;

public class Main23 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		ArrayList<String> personas = new ArrayList<>();
		
		String p;
		
		while(true) {
			System.out.println("Introduce nombres de personas o 0 para parar");
			p=teclado.next();
			if(p.equals("0")) {
				break;
			}
			personas.add(p);
		}
		
		for(String pe : personas) {
			System.out.println(pe + "\n");
		}


	}

}
