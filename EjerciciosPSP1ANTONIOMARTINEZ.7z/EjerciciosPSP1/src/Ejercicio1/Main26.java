package Ejercicio1;

import java.util.Scanner;

public class Main26 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);

		
		int notas[] = new int[10];
		
        for (int i = 0; i < 10; i++) {
            System.out.println("Introduce la nota numero " + (i + 1));
            notas[i]=teclado.nextInt();
        }
        calificaiones(notas);
	}
	

	
	public static void calificaiones(int[] numuser) {

        int contsuspensos = 0;
        int contaprobados = 0;
        int contnotables = 0;
        int contsobre = 0;
        int contmatricula = 0;
        
       for (int i = 0; i < 10 ; i++) {
    	   if (numuser[i] < 5) { 
               contsuspensos++;
           } else if (numuser[i] >= 5 && numuser[i] < 7) { 
               contaprobados++;
           } else if (numuser[i] >= 7 && numuser[i] < 9) { 
               contnotables++;
               contaprobados++;
           } else if (numuser[i] >= 9 && numuser[i] < 10) {
               contsobre++;
               contaprobados++;
           } else if (numuser[i] == 10) { 
               contmatricula++;
               contaprobados++;
           }
		
	}

        System.out.println("En total hay: " + contaprobados + " aprobados");
        System.out.println("En total hay: " + contsuspensos + " suspensos");
        System.out.println("En total hay: " + contnotables + " notables");
        System.out.println("En total hay: " + contsobre + " sobresalientes");
        System.out.println("En total hay: " + contmatricula + " matrículas de honor");
	}

}
