package Ejercicio1;

public class Main19 {

	public static void main(String[] args) {
		
		for (int i = 0; i <= 127; i++) {
			System.out.println("ASCII: " + i + " Carácter: " + (char) i);
		}

	}

}
