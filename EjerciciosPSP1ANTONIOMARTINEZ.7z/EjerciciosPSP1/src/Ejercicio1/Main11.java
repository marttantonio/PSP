package Ejercicio1;

import java.util.Scanner;

public class Main11 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		
		char[] letras = {'T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 
	                'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E'};
	
		System.out.println("Introduce los numeros de tu DNI sin la letra:");
		int numdni = teclado.nextInt();  
		
		int restoletra = numdni % 23;
		
		char letra = letras[restoletra];
		
		System.out.println("Al DNI: " + numdni + " le corresponde la letra: " + letra);
	}

}
