package Ejercicio1;

import java.util.Scanner;

public class Main6 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		
		int num1;
		int num2;
		int num3;
		int num4;
		int num5;
		

		System.out.println("Introduce el numero 1");
		num1=teclado.nextInt();
		System.out.println("Introduce el numero 2");
		num2=teclado.nextInt();
		System.out.println("Introduce el numero 3");
		num3=teclado.nextInt();
		System.out.println("Introduce el numero 4");
		num4=teclado.nextInt();
		System.out.println("Introduce el numero 5");
		num5=teclado.nextInt();
		
		System.out.println("La suma total es: " + (num1+num2+num3+num4+num5));

	}

}
