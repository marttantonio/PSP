package Ejercicio1;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Main14 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		
		double radio;
		double diametro;
		double area;
		
		System.out.println("Introduce el radio del círculo:");
		radio=teclado.nextDouble();
		
		
		DecimalFormat df = new DecimalFormat("#.000");
		
		diametro = radio * 2;
		area = 3.14 * Math.pow(radio, 2);
		
		String diaf = df.format(diametro);
		String areaf = df.format(area);
		System.out.println(diaf);
		System.out.println(areaf);
	}
}