package Ejercicio1;

import java.util.Scanner;

public class Main3 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduce el primer numero");
		int num1= teclado.nextInt();
		
		System.out.println("Introduce el segundo numero");
		int num2 = teclado.nextInt();
		
		System.out.println("La suma es: " + (num1+num2));
	}

}
