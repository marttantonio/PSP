package Ejercicio1;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main25 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        ArrayList<Integer> numeros = new ArrayList<>();
        int numuser;
        Random rand = new Random();
        int numeroAleatorio = rand.nextInt(10) + 1;
        boolean adivinado = false;  


        for (int i = 0; i < 3; i++) {
            System.out.println("Intente adivinar mi número entre 1 y 10 (intento " + (i + 1) + " de 3):");
            numuser = teclado.nextInt();
            numeros.add(numuser);

            if (numuser == numeroAleatorio) {
                adivinado = true;
                System.out.println("¡Felicidades! Adivinaste el número.");

                System.out.println("Elige uno de estos 3 premios:");
                System.out.println("1. Una rueda de bicicleta (pinchada)");
                System.out.println("2. Un preservativo (pinchado)");
                System.out.println("3. Un globo de helio (sin helio, está pinchado)");
                
                int opcion1 = teclado.nextInt();

                switch (opcion1) {
                    case 1:
                        System.out.println("Disfruta de tu rueda pinchada.");
                        break;
                    case 2:
                        System.out.println("Disfruta de tu preservativo pinchado.");
                        break;
                    case 3:
                        System.out.println("Disfruta de tu globo de helio pinchado.");
                        break;
                    default:
                        System.out.println("Opción no válida. Elige un premio sin miedo.");
                }
                break; 
            } else {
                System.out.println("Ese no es el número, intenta de nuevo.");
            }
        }
        if (!adivinado) {
            System.out.println("Lo siento, no adivinaste el número. El número era: " + numeroAleatorio);
        }
    }
}

