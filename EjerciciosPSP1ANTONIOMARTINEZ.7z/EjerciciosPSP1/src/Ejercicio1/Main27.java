package Ejercicio1;

import java.util.Scanner;

public class Main27 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		
	
		System.out.println("Introduce los numeros de tu DNI sin la letra:");
		int numdni = teclado.nextInt();  
		
		
		
		char letra=calculoLetra(numdni);
		
		System.out.println("Al DNI: " + numdni + " le corresponde la letra: " + letra);

	}
	
	public static char calculoLetra(int dni) {
		char letra;
		char[] letras = {'T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 
                'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E'};
                
        int restoletra = dni % 23;
        letra = letras[restoletra];
		return letra;
	}

}
