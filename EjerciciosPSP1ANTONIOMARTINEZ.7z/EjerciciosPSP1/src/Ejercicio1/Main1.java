package Ejercicio1;

public class Main1 {

	public static void main(String[] args) {

		int numa=5;
		int numb=10;
		
		System.out.println(numa+numb);
	}

}
