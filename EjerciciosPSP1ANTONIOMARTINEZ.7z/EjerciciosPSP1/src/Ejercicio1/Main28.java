package Ejercicio1;

import java.util.ArrayList;

public class Main28 {

	public static void main(String[] args) {
		
		ArrayList<Vehiculo> vehiculos = new ArrayList<>();
		
		Vehiculo v1 = new Vehiculo("Moto", "Toyota", "Rojo");
		Vehiculo v2 = new Vehiculo("Coche", "Honda", "Verde");
		Vehiculo v3 = new Vehiculo("Triciclo", "BMX", "Azul");
		
		vehiculos.add(v1);
		vehiculos.add(v2);
		vehiculos.add(v3);
		
		for(Vehiculo ve : vehiculos) {
			System.out.println(ve.getTipo() + " " + ve.getMarca() + " " + ve.getModelo());
		}
	}

}
