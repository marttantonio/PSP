package Ejercicio1;

import java.util.Scanner;

public class Main18 {

	public static void main(String[] args) {
		
Scanner teclado = new Scanner(System.in);
		
		String contrasena;
		
		System.out.println("Introduce una contraseña con 5 letras, mínimo una mayúscula y un número");
		contrasena=teclado.next();
		
		boolean tieneNumero = false;
        boolean tieneMayuscula = false;

        for (int i = 0; i < contrasena.length(); i++) {
            char c = contrasena.charAt(i);

            if (Character.isDigit(c)) {
                tieneNumero = true;
            }

            if (Character.isUpperCase(c)) {
                tieneMayuscula = true;
            }

            if (tieneNumero && tieneMayuscula) {
                break;
            }
        }

        if (contrasena.length() >= 5 && tieneNumero && tieneMayuscula) {
            System.out.println("Contraseña válida.");
            
            System.out.println("Ahora repita la contraseña para validarla");
            String contrepetir = teclado.next();
            if(contrasena.equals(contrepetir)) {
            	System.out.println("Contraseña establecida con éxito");
            }else {
            	System.out.println("Error, no es la misma contraseña");
            }
        } else {
            System.out.println("La contraseña no cumple con los requisitos.");
        }


	}
}
