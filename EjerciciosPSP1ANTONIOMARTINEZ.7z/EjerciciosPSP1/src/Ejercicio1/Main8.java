package Ejercicio1;

import java.util.Scanner;

public class Main8 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introuce un número del 1 al 12 y te diré al mes del año al que corresponde");
		int nummes=teclado.nextInt();
		
		if(nummes==1) {
			System.out.println("El numero corresponde a Enero");
		} else if(nummes==2) {
			System.out.println("El numero corresponde a Febrero");
		} else if(nummes==3) {
			System.out.println("El numero corresponde a Marzo");
		} else if(nummes==4) {
			System.out.println("El numero corresponde a Abril");
		} else if(nummes==5) {
			System.out.println("El numero corresponde a Mayo");
		} else if(nummes==6) {
			System.out.println("El numero corresponde a Junio");
		} else if(nummes==7) {
			System.out.println("El numero corresponde a Julio");
		} else if(nummes==8) {
			System.out.println("El numero corresponde a Agosto");
		} else if(nummes==9) {
			System.out.println("El numero corresponde a Septiembre");
		} else if(nummes==10) {
			System.out.println("El numero corresponde a Octubre");
		} else if(nummes==11) {
			System.out.println("El numero corresponde a Noviembre");
		} else if(nummes==12) {
			System.out.println("El numero corresponde a Diciembre");
		} else {
			System.out.println("Introduce un numero entre el 1 y el 12");
		}
	}

}
