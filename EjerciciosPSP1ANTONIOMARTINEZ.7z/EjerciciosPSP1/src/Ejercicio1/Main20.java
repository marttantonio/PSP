package Ejercicio1;

public class Main20 {

	public static void main(String[] args) {
		for (int i = 0; i <= 255; i++) {
			System.out.println("ASCII: " + i + " Carácter: " + (char) i);
		}


	}

}
