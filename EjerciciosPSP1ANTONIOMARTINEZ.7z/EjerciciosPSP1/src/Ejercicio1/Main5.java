package Ejercicio1;

import java.util.Scanner;

public class Main5 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		
		int num1;
		int num2;
		
		do {
			
			System.out.println("Introduzca el primer numero");
			num1=teclado.nextInt();
			System.out.println("Introduzca el segundo numero");
			num2=teclado.nextInt();
			
		}while(num1!=num2);
	}

}
