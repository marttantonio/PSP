package Ejercicio1;

import java.util.Scanner;

public class Main12 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);

        int contsuspensos = 0;
        int contaprobados = 0;
        int contnotables = 0;
        int contsobre = 0;
        int contmatricula = 0;

        int numuser;

        for (int i = 0; i < 10; i++) {
            System.out.println("Introduce la nota numero " + (i + 1));
            numuser = teclado.nextInt();

            if (numuser < 5) { 
                contsuspensos++;
            } else if (numuser >= 5 && numuser < 7) { 
                contaprobados++;
            } else if (numuser >= 7 && numuser < 9) { 
                contnotables++;
                contaprobados++;
            } else if (numuser >= 9 && numuser < 10) {
                contsobre++;
                contaprobados++;
            } else if (numuser == 10) { 
                contmatricula++;
                contaprobados++;
            } else { 
                System.out.println("Nota no válida, por favor introduce una nota entre 0 y 10.");
            }
        }

        System.out.println("En total hay: " + contaprobados + " aprobados");
        System.out.println("En total hay: " + contsuspensos + " suspensos");
        System.out.println("En total hay: " + contnotables + " notables");
        System.out.println("En total hay: " + contsobre + " sobresalientes");
        System.out.println("En total hay: " + contmatricula + " matrículas de honor");
	}
}
