package Ejercicio1;

import java.util.Scanner;

public class Main13 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		
		float centigrados;
		float farenheit=32;
		
		
		System.out.println("Introduce los Cº que quieres convertir");
		centigrados=teclado.nextFloat();
		
		System.out.println("En total son: " + (centigrados + farenheit) + " farenheits");
		
		
	}

}
