package Ejercicio1;

import java.util.Random;
import java.util.Scanner;

public class Main24 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		int numuser;
		Random rand = new Random();
		int numeroAleatorio = rand.nextInt(10) + 1;
		
		
		do {
			
			System.out.println("Intente adivinar mi número");
			numuser=teclado.nextInt();
			
			if(numuser==numeroAleatorio) {
				System.out.println("Eliga uno de de estos 3 premios");
				System.out.println("1.Una rueda de una bicicleta(pinchada)");
				System.out.println("2.Un preservativo(pinchado)");
				System.out.println("3.Un globo de helio(sin helio ya que está pinchado)");
				int opcion1=teclado.nextInt();
				
				switch (opcion1) {
				case 1:
					System.out.println("Disfrute de su rueda pinchada");
					break;
				case 2:
					System.out.println("Disfrute de su preservativo pinchado");
					break;
				case 3:
					System.out.println("Disfrute de su globo de helio pinchado");
					break;
				default:
					System.out.println("Elija uno, sin miedo");
				}
			}
			
		}while(numuser!=numeroAleatorio);

	}

}
