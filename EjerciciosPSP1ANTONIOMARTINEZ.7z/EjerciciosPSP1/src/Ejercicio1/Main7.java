package Ejercicio1;

import java.util.Scanner;

public class Main7 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		
		int sumatotal = 0;
		
		for (int i = 0; i <5 ; i++) {
			System.out.println("Introduzca el numero "  + (i+1));
			int num=teclado.nextInt();
			sumatotal=num+sumatotal;
		}
		System.out.println(sumatotal);
	}

}
