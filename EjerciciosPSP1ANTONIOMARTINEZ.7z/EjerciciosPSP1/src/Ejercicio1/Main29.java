package Ejercicio1;

public class Main29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
