package Ejercicio1;

public class Main30 {

	public static void main(String[] args) {
		/*
		 * 
		 * PASO 1.
		 * Antes de empaquetar tu programa en un archivo JAR, necesitas compilarlo. Supongamos que tienes un archivo Java llamado Main26.java 
		 * 
		 * PASO 2.
		 * Para compilar tu archivo Java en bytecode (.class), usa el compilador de Java (javac). Asegúrate de que el archivo Main26.java esté en una carpeta accesible desde la terminal.
		 *Abre la terminal (o consola) y navega hasta la carpeta donde tienes el archivo Main26.java. Luego, ejecuta el siguiente comando:
		 * javac Main26.java
		 * 
		 * PASO 3.
		 * Una vez que hayas compilado tu código, puedes empaquetarlo en un archivo JAR. Para crear un archivo JAR ejecutable, necesitas un manifiesto que le indique al archivo JAR qué clase contiene el método main.
		 * 
		 * PASO 4.
		 * Crear un archivo MANIFEST.MF
		 *Crea un archivo de texto llamado MANIFEST.MF con el siguiente contenido (puedes usar cualquier editor de texto como el Bloc de notas, Visual Studio Code, etc.):
		 * Manifest-Version: 1.0
		 * Main-Class: Main26 
		 * 
		 * PASO 5.
		 * Este manifiesto le indica al archivo JAR cuál es la clase principal que se debe ejecutar.
		 * Crear el archivo .JAR
		 * Una vez que tienes el archivo MANIFEST.MF y los archivos .class, puedes crear el archivo JAR ejecutable con el siguiente comando:
		 * jar cfm Main26.jar MANIFEST.MF Main26.class
		 * 
		 * PASO 6.
		 * Después de crear el archivo JAR, puedes ejecutarlo directamente desde la terminal o consola. Usa el siguiente comando:
		 * java -jar Main26.jar
		 * 
		 * 
		 */

	}

}
