package Ejercicio1;

import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		int num1;
		int num2;
		int total = 0;
		
		
		System.out.println("Escriba el primer número");
		num1 = teclado.nextInt();
		
		System.out.println("Escriba el segundo número");
		num2 = teclado.nextInt();
		
		for(int i = (num1+1); i < num2; i++) {
			System.out.println(i);
			total+=i;
			if(i/2 == 0 || i/3 == 0) {
				System.out.println("El número: " + i + " es primo");
			}
		}
		System.out.println(total);

		
	}
}
