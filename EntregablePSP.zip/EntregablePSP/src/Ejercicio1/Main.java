package Ejercicio1;

public class Main {

	public static void main(String[] args) {
		
		App a = new App();
		
		System.out.println(a.sayHello());

	}

}
