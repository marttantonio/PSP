package Ejercicio1;

import java.util.ArrayList;
import java.util.Scanner;

public class Main3 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		int num = 0;
		int numMayor = 0;
		String nombre;
		
		ArrayList<String> companyeros = new ArrayList<>();
		companyeros.add("Jose");
		companyeros.add("Maria");
		companyeros.add("Luis");
		companyeros.add("Pepe");
		companyeros.add("Salva");
		companyeros.add("Antonio");
		
		do {
			System.out.println("Introduce un número (0 para acabar)");
			num=teclado.nextInt();
			if(numMayor<num) {
				numMayor=num;
			}
			
			if(num==1) {
				System.out.println("El número 1 corresponde a: " + "Jose");
			}
			if(num==2) {
				System.out.println("El número 2 corresponde a: " + "Maria");
			}
			if(num==3) {
				System.out.println("El número 3 corresponde a: " + "Luis");
			}
			if(num==4) {
				System.out.println("El número 4 corresponde a: " + "Pepe");
			}
			if(num==5) {
				System.out.println("El número 5 corresponde a: " + "Salva");
			}
			if(num==6) {
				System.out.println("El número 6 corresponde a: " + "Antonio");
			}
			
			
		}while(num!=0);
		
		System.out.println("El mayor número es: " + numMayor);
		
		int[] numeros = new int[6];
		
		
	}
}
