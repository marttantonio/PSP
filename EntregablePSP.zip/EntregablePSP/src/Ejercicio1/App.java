package Ejercicio1;

public class App {
	
	public static String sayHello() {
		String saludo=null;
		
		saludo = "Hola mundo";
		
		return saludo;
	}

}
